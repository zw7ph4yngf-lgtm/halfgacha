let s=JSON.parse(localStorage.getItem('hg'))||{money:100,win:0,lose:0,lossAccum:0,a:[false,false,false]};
const A=[['始まり','当たり1回'],['残念！','はずれ1回'],['逆の運','はずれ2連続']];
const money=document.getElementById('money'),win=document.getElementById('win'),lose=document.getElementById('lose'),achs=document.getElementById('achs'),btn=document.getElementById('btn'),result=document.getElementById('result');
function save(){localStorage.setItem('hg',JSON.stringify(s));}
function draw(){money.textContent=s.money;win.textContent=s.win;lose.textContent=s.lose;achs.innerHTML=A.map((x,i)=>`<li class="${s.a[i]?'done':''}">${s.a[i]?'✅':'⬜'} ${x[0]} - ${x[1]}</li>`).join('');}
btn.onclick=()=>{s.money-=10;if(Math.random()<0.5){s.money+=25;s.win++;if(s.win>=3)s.money+=s.win*10;if(s.lose>=3)s.money+=Math.floor(s.lossAccum/2);s.lose=0;s.lossAccum=0;s.a[0]=true;result.textContent='🎉 当たり';if(s.money<=0){alert('ゲームオーバー');btn.disabled=true;}}else{s.money-=25;s.win=0;s.lose++;s.lossAccum+=35;s.a[1]=true;if(s.lose>=2)s.a[2]=true;result.textContent='❌ はずれ';}save();draw();};
draw();